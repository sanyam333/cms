﻿using System;
using System.Threading.Tasks;
using SQLite.Net.Attributes;
using System.IO;
using System.Linq;
using Windows.Storage;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using cms.Helpers;
using cms.Objects;
using SQLite.Net;
using SQLite.Net.Platform.WinRT;
using System.Diagnostics;
using Windows.UI.Xaml.Data;
using System.Collections.Generic;
using CMS.Objects;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace cms
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class UserProfilePage : Page
    {
        private User currentUser;
        private Image[] userIDImages;
        private double idImageMaxWidth = 0;
        

        private WebcamHelper webcam;
       

        public UserProfilePage()
        {
            this.InitializeComponent();
            
        }

        private static SQLiteConnection DbConnection
        {
            get
            {
                return new SQLiteConnection(
                    new SQLitePlatformWinRT(),
                    Path.Combine(ApplicationData.Current.LocalFolder.Path, "Storage.sqlite"));
            }
        }
        public class DebugTraceListener : ITraceListener
        {
            public void Receive(string message)
            {
                Debug.WriteLine(message);
            }
        }

     
        /// <summary>
        /// Triggered every time the page is navigated to.
        /// </summary>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            try
            {
                // Catches the passed UserProfilePage parameters
                UserProfileObject userProfileParameters = e.Parameter as UserProfileObject;

                // Sets current user as the passed through User object
                currentUser = userProfileParameters.User;
                // Sets the UserNameBlock as the current user's name
                UserNameBlock.Text = currentUser.Name;

                // Sets the local WebcamHelper as the passed through intialized one
                webcam = userProfileParameters.WebcamHelper;
            }
            catch
            {
                // Something went wrong... It's likely the page was navigated to without a User parameter. Navigate back to MainPage
                Frame.Navigate(typeof(MainPage));
            }
        }

        

        private void PhotoGrid_Loaded(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            // Populate photo grid with user ID photos:
            PopulatePhotoGrid();
        }

        /// <summary>
        /// Populates PhotoGrid on UserProfilePage.xaml with photos in ImageFolder of passed through user object
        /// </summary>
        private async void PopulatePhotoGrid()
        {
            // Sets max width to allow 6 photos to sit in one row
            idImageMaxWidth = PhotoGrid.ActualWidth / 6 - 10;

            var filesInFolder = await currentUser.ImageFolder.GetFilesAsync();

            userIDImages = new Image[filesInFolder.Count];

            for (int i = 0; i < filesInFolder.Count; i++)
            {
                var photoStream = await filesInFolder[i].OpenAsync(FileAccessMode.Read);
                BitmapImage idImage = new BitmapImage();
                await idImage.SetSourceAsync(photoStream);

                Image idImageControl = new Image();
                idImageControl.Source = idImage;
                idImageControl.MaxWidth = idImageMaxWidth;

                userIDImages[i] = idImageControl;
            }

            PhotoGrid.ItemsSource = userIDImages;
        }

        /// <summary>
        /// Triggered when the user clicks the add photo button located in the app bar
        /// </summary>
        private async void AddButton_Tapped(object sender, TappedRoutedEventArgs e)
        {
           
            // Captures photo from current webcam stream
            StorageFile imageFile = await webcam.CapturePhoto();
            // Moves the captured file to the current user's ID image folder
            await imageFile.MoveAsync(currentUser.ImageFolder);
            // Update photo grid
            PopulatePhotoGrid();
            // Add to Oxford
            OxfordFaceAPIHelper.AddImageToWhitelist(imageFile, currentUser.Name);
        }

        /// <summary>
        /// Triggered when the user clicks the delete user button located in the app bar
        /// </summary>
        private async void DeleteButton_Tapped(object sender, TappedRoutedEventArgs e)
        {
            // Delete the user's folder
            await currentUser.ImageFolder.DeleteAsync();

            // Remove user from Oxford
            OxfordFaceAPIHelper.RemoveUserFromWhitelist(currentUser.Name);

            // Stop camera preview
            await webcam.StopCameraPreview();
            //delete users from database table userstable and coffee table
            string name = currentUser.Name;
            using (var db = DbConnection)
            {
                db.Execute("DELETE FROM Coffee WHERE UserName = ?", name);
                db.Execute("DELETE FROM userscoffee WHERE UserName = ?", name);
            }
                    // Navigate to MainPage
                    Frame.Navigate(typeof(MainPage));
        }

        /// <summary>
        /// Triggered when the user clicks the home button located in the app bar
        /// </summary>
        private async void HomeButton_Tapped(object sender, TappedRoutedEventArgs e)
        {
            // Stop camera preview
            await webcam.StopCameraPreview();

            // Navigate to MainPage
            Frame.Navigate(typeof(MainPage));
        }
      
        private void Savecalender_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            // Create a new connection 
            using (var db = DbConnection)
            {
               string name = currentUser.Name;
               
                DateTime dt = new DateTime(mydate.Date.Date.Ticks+mytime.Time.Ticks);
                // Activate Tracing 
                db.TraceListener = new DebugTraceListener();
                // Create the table if it does not exist 
                var c = db.CreateTable<Coffee>();
                var info = db.GetMapping(typeof(Coffee));               
                Coffee coffee = new Coffee();
                coffee.UserName = name;
                coffee.DaytimeOfCoffee = dt;
                coffee.state = 0;//0 means it is waiting
             //insert data in coffee table
                var i = db.Insert(coffee);
                usertextBlock.Text = "Your Coffee scheduled is saved";
            }
           

        }

        private void Startcoffee_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            using (var db = DbConnection)
            {
                string name = currentUser.Name;

                DateTime dt =  DateTime.Now;
                // Activate Tracing 
                db.TraceListener = new DebugTraceListener();
                // Create the table if it does not exist 
                var c = db.CreateTable<Coffee>();
                var info = db.GetMapping(typeof(Coffee));
                Coffee coffee = new Coffee();
                coffee.UserName = name;
                coffee.DaytimeOfCoffee = dt;
                coffee.state = 1;//  1 state means it is in processing.
                //insert data in coffee table
                var i = db.Insert(coffee);

                usertextBlock.Text = "Your Coffee will prepared soon";

            }
        }

        private void settingscoffee_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            CoffeegridView.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void closebutton_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            CoffeegridView.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
         
        }

        private void Deleteschedule_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            string name = currentUser.Name;
            using (var db = DbConnection)
            {
                db.Execute("DELETE FROM Coffee WHERE UserName = ? AND state = 0", name);
                usertextBlock.Text = "All The schedules are deleted";
            }

        }

      

        private void History_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
           
            using (var db = DbConnection)
            {
                string name = currentUser.Name;
                
                // Create the table if it does not exist 
                List<Coffee> people = db.Table<Coffee>().Where(j =>j.UserName == currentUser.Name ).OrderBy(j => j.DaytimeOfCoffee).ToList();
                string text = "";
                foreach (var message in people)
                {
                    text = text + message.UserName + " scheduled at " + message.DaytimeOfCoffee + Environment.NewLine;
                }

                usertextBlock.Text = text;

            }
        }
    }
}
