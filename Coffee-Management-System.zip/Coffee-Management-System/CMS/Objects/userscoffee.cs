﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Objects
{
    /// <summary>
    /// All the users are stored table structure
    /// </summary>
    public class userscoffee
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the User name.
        /// </summary>
        [MaxLength(64)]
        public string UserName { get; set; }



        /// <summary>
        /// Gets or sets the day of Coffee.
        /// </summary>
        public string PhoneNumber { get; set; }

        public int noofcoffee { get; set; }


    }
}
