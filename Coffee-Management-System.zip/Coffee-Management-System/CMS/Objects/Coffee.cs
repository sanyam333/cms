﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Objects
{
    /// <summary>
    /// All the coffee shedules are stored table structure
    /// </summary>
    public class Coffee
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the User name.
        /// </summary>
        [MaxLength(64)]
        public string UserName { get; set; }



        /// <summary>
        /// Gets or sets the day of Coffee.
        /// </summary>
        public DateTime DaytimeOfCoffee { get; set; }   

        public int state { get; set; }
       



    }
}
