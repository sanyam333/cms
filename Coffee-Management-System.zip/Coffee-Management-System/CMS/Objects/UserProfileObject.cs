﻿using cms.Helpers;

namespace cms.Objects
{
    /// <summary>
    /// Object specifically to be passed to UserProfilePage that contains an instance of the WebcamHelper and a User object
    /// </summary>
    class UserProfileObject
    {
        /// <summary>
        /// An initialized User object
        /// </summary>
        public User User { get; set; }

        /// <summary>
        /// An initialized WebcamHelper 
        /// </summary>
        public WebcamHelper WebcamHelper { get; set; }

        /// <summary>
        /// Initializes a new UserProfileObject with relevant information
        /// </summary>
        public UserProfileObject(User user, WebcamHelper webcamHelper)
        {
            User = user;
            WebcamHelper = webcamHelper;
        }
    }
}
