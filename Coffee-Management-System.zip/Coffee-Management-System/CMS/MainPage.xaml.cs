﻿using cms.FacialRecognition;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Windows.Devices.Gpio;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using cms.Helpers;
using cms.Objects;
using SQLite.Net;
using SQLite.Net.Platform.WinRT;
using System.Linq;
using System.IO;
using CMS.Objects;
using Windows.Devices.I2c;
using System.Threading;
using Windows.Devices.Enumeration;



namespace cms
{
    public sealed partial class MainPage : Page
    {
        
        /// <summary>
        /// To establish connection to sqlite
        /// </summary>
        private static SQLiteConnection DbConnection
        {
            get
            {
                return new SQLiteConnection(
                    new SQLitePlatformWinRT(),
                    Path.Combine(ApplicationData.Current.LocalFolder.Path, "Storage.sqlite"));
            }
        }

        
        // I2c device connections
        private I2cDevice Device;
        // Timer to refresh pressure values 
        private Timer periodicTimer;

        // Webcam Related Variables:
        private WebcamHelper webcam;

        // Oxford Related Variables:
        private bool initializedOxford = false;

        // Whitelist Related Variables:
        private List<User> whitelistedUsers = new List<User>();
        private StorageFolder whitelistFolder;
        private bool currentlyUpdatingWhitelist;

        // Speech Related Variables:
        private SpeechHelper speech;

        // GPIO Related Variables:
        private GpioHelper gpioHelper;
        private bool gpioAvailable;
        private bool quickcoffeeJustPressed = false;

        // GUI Related Variables:
        private double userIDPhotoGridMaxWidth = 0;

        /// <summary>
        /// Called when the page is first navigated to.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();
            /// <summary>
            // when users coffee shedule is equal to current time and date then it is processed from waiting to in queue processing
            /// </summary>
            using (var db = DbConnection)
            {
                

              
                List<Coffee> coffee = db.Table<Coffee>().Where(j => j.state == 0).ToList();
                foreach (var check in coffee)
                {
                    if (check.DaytimeOfCoffee == DateTime.Now)
                    {
                        check.UserName = check.UserName;
                        check.state = 1;
                       db.Update(check);
                       
                    }
                }
            }
            // causes to read values serially from mkr1000
            if (GeneralConstants.Enableconnection == true )
            { initcomunica(); }
            
            // Causes this page to save its state when navigating to other pages
            NavigationCacheMode = NavigationCacheMode.Enabled;

            if (initializedOxford == false)
            {
                // If Oxford facial recognition has not been initialized, attempt to initialize it
                InitializeOxford();
            }

            if(gpioAvailable == false)
            {
                // If GPIO is not available, attempt to initialize it
                InitializeGpio();
            }

            // If user has set the DisableLiveCameraFeed within Constants.cs to true, disable the feed:
            if(GeneralConstants.DisableLiveCameraFeed)
            {
                LiveFeedPanel.Visibility = Visibility.Collapsed;
                DisabledFeedGrid.Visibility = Visibility.Visible;
            }
            else
            {
                LiveFeedPanel.Visibility = Visibility.Visible;
                DisabledFeedGrid.Visibility = Visibility.Collapsed;
            }
        }
        /// <summary>
        /// calles fuction and retreives device which is connected through I2C
        /// </summary>
        private async void initcomunica()
        {
            var settings = new I2cConnectionSettings(0x40); // Arduino address
            Debug.WriteLine(settings);
            settings.BusSpeed = I2cBusSpeed.StandardMode;
            Debug.WriteLine(settings.BusSpeed);
            string aqs = I2cDevice.GetDeviceSelector("I2C1");
            Debug.WriteLine(aqs);

            var dis = await DeviceInformation.FindAllAsync(aqs);
            Debug.WriteLine(dis);
            Debug.WriteLine(dis[0].Id);
            Device = await I2cDevice.FromIdAsync(dis[0].Id, settings);

            periodicTimer = new Timer(this.TimerCallback, null, 0, 100); // Create a timmer
        }
        /// <summary>
        /// Timers which keeps reading values which is sent through arduino mkr1000
        /// </summary>
        private void TimerCallback(object state)

        {
          
            
        

            byte[] RegAddrBuf = new byte[] { 0x40 };

           byte[] ReadBuf = new byte[4];

            try

            {
                // read the data
                Device.Read(ReadBuf); 
            }

            catch (Exception f)

            {

                Debug.WriteLine(f.Message);

            }

          
           
            if (BitConverter.IsLittleEndian)
                Array.Reverse(ReadBuf);

            int presurevalue = BitConverter.ToInt32(ReadBuf, 0);
            

            Debug.WriteLine(presurevalue);
            //  if it crosses pressure value i.e coffee mug is full and hence update No of coffee +1... which increments users number of coffee
            if (presurevalue >= GeneralConstants.pressurepad)
                {
                    //  if it crosses pressure value i.e coffee mug is full and hence update state to 2... which means coffee is ready
                    using (var db = DbConnection)
                    {
                    // Create the table if it does not exist 
                    Coffee m = (from p in db.Table<Coffee>()
                                where p.state == 1
                                select p).FirstOrDefault();
                  
                    if (m != null)
                    {
                        m.UserName = m.UserName;
                        m.state = 2;
                        db.Update(m);
                        userscoffee use = (from p in db.Table<userscoffee>()
                                           where p.UserName == m.UserName
                                           select p).FirstOrDefault();
                        use.UserName = use.UserName;
                        use.noofcoffee = use.noofcoffee + 1;
                        db.Update(use);
                    }
                    
               
                    }
                   
                   
                }
           
              

        }
        /// <summary>
        /// Triggered every time the page is navigated to.
        /// </summary>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if(initializedOxford)
            {
                UpdateWhitelistedUsers();
            }
        }

        /// <summary>
        /// Called once, when the app is first opened. Initializes Oxford facial recognition.
        /// </summary>
        public async void InitializeOxford()
        {
            // initializedOxford bool will be set to true when Oxford has finished initialization successfully
            initializedOxford = await OxfordFaceAPIHelper.InitializeOxford();

            // Populates UI grid with whitelisted users
            UpdateWhitelistedUsers();
        }

        /// <summary>
        /// Called once, when the app is first opened. Initializes device GPIO.
        /// </summary>
        public void InitializeGpio()
        {
            try
            {
                // Attempts to initialize application GPIO. 
                gpioHelper = new GpioHelper();
                gpioAvailable = gpioHelper.Initialize();
            }
            catch
            {
                // This can fail if application is run on a device, such as a laptop, that does not have a GPIO controller
                gpioAvailable = false;
                Debug.WriteLine("GPIO controller not available.");
            }

            // If initialization was successfull, attach quickcoffee pressed event handler
            if (gpioAvailable)
            {
                gpioHelper.GetquickcoffeePin().ValueChanged += quickcoffeePressed;
            }
        }

        /// <summary>
        /// Triggered when webcam feed loads both for the first time and every time page is navigated to.
        /// If no WebcamHelper has been created, it creates one. Otherwise, simply restarts webcam preview feed on page.
        /// </summary>
        private async void WebcamFeed_Loaded(object sender, RoutedEventArgs e)
        {
            if (webcam == null || !webcam.IsInitialized())
            {
                // Initialize Webcam Helper
                webcam = new WebcamHelper();
                await webcam.InitializeCameraAsync();

                // Set source of WebcamFeed on MainPage.xaml
                WebcamFeed.Source = webcam.mediaCapture;

                // Check to make sure MediaCapture isn't null before attempting to start preview. Will be null if no camera is attached.
                if (WebcamFeed.Source != null)
                {
                    // Start the live feed
                    await webcam.StartCameraPreview();
                }
            }
            else if(webcam.IsInitialized())
            {
                WebcamFeed.Source = webcam.mediaCapture;

                // Check to make sure MediaCapture isn't null before attempting to start preview. Will be null if no camera is attached.
                if (WebcamFeed.Source != null)
                {
                    await webcam.StartCameraPreview();
                }
            }
        }

        /// <summary>
        /// Triggered when media element used to play synthesized speech messages is loaded.
        /// Initializes SpeechHelper and greets user.
        /// </summary>
        private async void speechMediaElement_Loaded(object sender, RoutedEventArgs e)
        {
            if (speech == null)
            {
                speech = new SpeechHelper(speechMediaElement);
                await speech.Read(SpeechContants.InitialGreetingMessage);
            }
            else
            {
                // Prevents media element from re-greeting user
                speechMediaElement.AutoPlay = false;
            }
        }

        /// <summary>
        /// Triggered when the whitelisted users grid is loaded. Sets the size of each photo within the grid.
        /// </summary>
        private void WhitelistedUsersGrid_Loaded(object sender, RoutedEventArgs e)
        {
            userIDPhotoGridMaxWidth = (WhitelistedUsersGrid.ActualWidth / 3) - 10;
        }

        /// <summary>
        /// Triggered when user presses physical Coffee button
        /// </summary>
        private async void quickcoffeePressed(GpioPin sender, GpioPinValueChangedEventArgs args)
        {
            if (!quickcoffeeJustPressed)
            {
                // Checks to see if even was triggered from a press or release of button
                if (args.Edge == GpioPinEdge.FallingEdge)
                {
                    //quickcoffee was just pressed
                    quickcoffeeJustPressed = true;

                    await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, async () =>
                    {
                        await quickcoffeePressed();
                    });

                }
            }
        }

        /// <summary>
        /// Triggered when user presses virtual quickcoffee app bar button
        /// </summary>
        private async void quickcoffeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (!quickcoffeeJustPressed)
            {
                quickcoffeeJustPressed = true;
                await quickcoffeePressed();
            }
        }

        /// <summary>
        /// Called when user hits physical or vitual quickcoffee buttons. Captures photo of current webcam view and sends it to Oxford for facial recognition processing.
        /// </summary>
        private async Task quickcoffeePressed()
        {
            // Display analysing users grid to inform user that quickcoffee press was registered
            AnalysingUserGrid.Visibility = Visibility.Visible;

            // List to store users recognized by Oxford Face API
            // Count will be greater than 0 if there is an authorized user at the coffee machine
            List<string> recognizedUsers = new List<string>();

            // Confirms that webcam has been properly initialized and oxford is ready to go
            if (webcam.IsInitialized() && initializedOxford)
            {
                // Stores current frame from webcam feed in a temporary folder
                StorageFile image = await webcam.CapturePhoto();

                try
                {
                    // Oxford determines whether or not the user is on the Whitelist and returns true if so
                    recognizedUsers = await OxfordFaceAPIHelper.IsFaceInWhitelist(image);                    
                }
                catch (FaceRecognitionException fe)
                {
                    switch (fe.ExceptionType)
                    {
                        // Fails and catches as a FaceRecognitionException if no face is detected in the image
                        case FaceRecognitionExceptionType.NoFaceDetected:
                            Debug.WriteLine("WARNING: No face detected in this image.");
                            break;
                    }
                }
                catch
                {
                    // General error. This can happen if there are no users authorized in the whitelist
                    Debug.WriteLine("WARNING: Oxford just threw a general expception.");
                }
                
                if(recognizedUsers.Count > 0)
                {
                    // If everything went well and a user was recognized, Start the Coffee machine:
                    StartCoffee(recognizedUsers[0]);
                }
                else
                {
                    // Otherwise, inform user that they were not recognized by the system
                    await speech.Read(SpeechContants.UserNotRecognizedMessage);
                }
            }
            else
            {
                if (!webcam.IsInitialized())
                {
                    // The webcam has not been fully initialized for whatever reason:
                    Debug.WriteLine("Unable to analyze user at coffee machine as the camera failed to initlialize properly.");
                    await speech.Read(SpeechContants.NoCameraMessage);
                }

                if(!initializedOxford)
                {
                    // Oxford is still initializing:
                    Debug.WriteLine("Unable to analyze user at coffee machine as Oxford Facial Recogntion is still initializing.");
                }
            }

            quickcoffeeJustPressed = false;
            AnalysingUserGrid.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Starts coffee machine and ask user to wait
        /// </summary>
        private async void StartCoffee(string userName)
        {
            // Greet user
            await speech.Read(SpeechContants.GeneralGreetigMessage(userName));

           if(gpioAvailable)
           {
                //Starts Coffee
                gpioHelper.StartCoffee();
           }
            using (var db = DbConnection)
            {
                string name = userName;

                DateTime dt = DateTime.Now;
                // Activate Tracing 
               
                // Create the table if it does not exist 
                var c = db.CreateTable<Coffee>();
                var info = db.GetMapping(typeof(Coffee));
                Coffee coffee = new Coffee();
                coffee.UserName = name;
                coffee.DaytimeOfCoffee = dt;
                coffee.state = 1;//  1 state means it is in processing.
                //insert data in coffee table
                var i = db.Insert(coffee);



            }
        }

        /// <summary>
        /// Called when user hits vitual add user button. Navigates to NewUserPage page.
        /// </summary>
        private async void NewUserButton_Click(object sender, RoutedEventArgs e)
        { 
            // Stops camera preview on this page, so that it can be started on NewUserPage
            await webcam.StopCameraPreview();

            //Navigates to NewUserPage, passing through initialized WebcamHelper object
            Frame.Navigate(typeof(NewUserPage), webcam);
        }

        /// <summary>
        /// Updates internal list of of whitelisted users (whitelistedUsers) and the visible UI grid
        /// </summary>
        private async void UpdateWhitelistedUsers()
        {
            // If the whitelist isn't already being updated, update the whitelist
            if (!currentlyUpdatingWhitelist)
            {
                currentlyUpdatingWhitelist = true;
                await UpdateWhitelistedUsersList();
                UpdateWhitelistedUsersGrid();
                currentlyUpdatingWhitelist = false;
            }
        }

        /// <summary>
        /// Updates the list of User objects with all whitelisted users stored on disk
        /// </summary>
        private async Task UpdateWhitelistedUsersList()
        {
            // Clears whitelist
            whitelistedUsers.Clear();

            // If the whitelistFolder has not been opened, open it
            if (whitelistFolder == null)
            {
                whitelistFolder = await KnownFolders.PicturesLibrary.CreateFolderAsync(GeneralConstants.WhiteListFolderName, CreationCollisionOption.OpenIfExists);
            }

            // Populates subFolders list with all sub folders within the whitelist folders.
            // Each of these sub folders represents the Id photos for a single user.
            var subFolders = await whitelistFolder.GetFoldersAsync();

            // Iterate all subfolders in whitelist
            foreach (StorageFolder folder in subFolders)
            {
                string userName = folder.Name;
                var filesInFolder = await folder.GetFilesAsync();

                var photoStream = await filesInFolder[0].OpenAsync(FileAccessMode.Read);
                BitmapImage userImage = new BitmapImage();
                await userImage.SetSourceAsync(photoStream);

                User whitelistedUser = new User(userName, folder, userImage, userIDPhotoGridMaxWidth);

                whitelistedUsers.Add(whitelistedUser);
            }
        }

        /// <summary>
        /// Updates UserInterface list of whitelisted users from the list of User objects (WhitelistedUsers)
        /// </summary>
        private void UpdateWhitelistedUsersGrid()
        {
            // Reset source to empty list
            WhitelistedUsersGrid.ItemsSource = new List<User>();
            // Set source of WhitelistedUsersGrid to the whitelistedUsers list
            WhitelistedUsersGrid.ItemsSource = whitelistedUsers;

            // Hide Oxford loading ring
            OxfordLoadingRing.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Triggered when the user selects a user in the WhitelistedUsersGrid 
        /// </summary>
        private void WhitelistedUsersGrid_ItemClick(object sender, ItemClickEventArgs e)
        {
            // Navigate to UserProfilePage, passing through the selected User object and the initialized WebcamHelper as a parameter
            Frame.Navigate(typeof(UserProfilePage), new UserProfileObject(e.ClickedItem as User, webcam));
        }

        /// <summary>
        /// Triggered when the user selects the Shutdown button in the app bar. Closes app.
        /// </summary>
        private void ShutdownButton_Click(object sender, RoutedEventArgs e)
        {
            // Exit app
            Application.Current.Exit();
        }

        private void NotificationButton_Click(object sender, RoutedEventArgs e)
        {
            Notification_gridview.Visibility = Visibility.Visible;
            NotificationtitleBlock.Visibility = Visibility.Visible;
            UsersTitleBlock.Visibility = Visibility.Collapsed;
            WhitelistedUsersGrid.Visibility = Visibility.Collapsed;
            down_grid.Visibility = Visibility.Visible;
            
           using (var db = DbConnection)
            {
                
                // Create the table if it does not exist 
                // Retreives all data which is already processed and ready for user to have their coffee
                List<Coffee> people = db.Table<Coffee>().Where(j =>j.DaytimeOfCoffee >= DateTime.Now && j.state == 2).OrderBy(j => j.DaytimeOfCoffee).ToList();
                string text = "";
                foreach (var message in people)
                {
                    text = text + message.UserName + ", Your coffee is ready! " + Environment.NewLine;
                }

               notificationtextBox.Text = text;

           }

        }

        private void UserListButton_Click(object sender, RoutedEventArgs e)
        {
            Notification_gridview.Visibility = Visibility.Collapsed;
            NotificationtitleBlock.Visibility = Visibility.Collapsed;
            UsersTitleBlock.Visibility = Visibility.Visible;
            WhitelistedUsersGrid.Visibility = Visibility.Visible;
            down_grid.Visibility = Visibility.Collapsed;
           
            
        }

        private void sheduledlist_Click(object sender, RoutedEventArgs e)
        {
            using (var db = DbConnection)
            {

                // Activate Tracing 
                //db.TraceListener = new DebugTraceListener();
                // Create the table if it does not exist 
                List<Coffee> people = db.Table<Coffee>().Where(j =>  j.state == 0).OrderBy(j => j.DaytimeOfCoffee).ToList();
                string text = "";
                foreach (var message in people)
                {
                    text = text + message.UserName + " scheduled at " + message.DaytimeOfCoffee + Environment.NewLine;
                   
                }

                notificationtextBox.Text = text;

            }
        }

        private void history_Click(object sender, RoutedEventArgs e)
        {
            using (var db = DbConnection)
            {

                // Activate Tracing 
                //db.TraceListener = new DebugTraceListener();
                // Create the table if it does not exist 
                List<Coffee> people = db.Table<Coffee>().Where(j =>  j.state == 2).OrderBy(j => j.DaytimeOfCoffee).ToList();
                string text = "";
                foreach (var message in people)
                {
                    text = text + message.UserName + " scheduled at " + message.DaytimeOfCoffee + Environment.NewLine;
                }

                notificationtextBox.Text = text;

            }
           
            
        }

        private void stats_Click(object sender, RoutedEventArgs e)
        {
            using (var db = DbConnection)
            {

                // Activate Tracing 
                //db.TraceListener = new DebugTraceListener();
                // Create the table if it does not exist 
                List<userscoffee> people = db.Table<userscoffee>().ToList();
                string text = "";
                foreach (var message in people)
                {
                    text = text + message.UserName + " drank " + message.noofcoffee + " cups" + Environment.NewLine;

                }

                notificationtextBox.Text = text;

            }
        }

        private void userreadylist_Click(object sender, RoutedEventArgs e)
        {
            using (var db = DbConnection)
            {

                // Activate Tracing 
                //db.TraceListener = new DebugTraceListener();
                // Create the table if it does not exist 
                List<Coffee> people = db.Table<Coffee>().Where(j =>  j.state == 1).OrderBy(j => j.DaytimeOfCoffee).ToList();
                string text = "";
                foreach (var message in people)
                {

                    text = text + message.UserName + ", Your coffee will be ready soon! " + Environment.NewLine;
                }

                notificationtextBox.Text = text;

            }
        }

    

       
    }
}
