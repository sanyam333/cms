﻿namespace cms
{
    /// <summary>
    /// General constant variables
    /// </summary>
    public static class GeneralConstants
    {
        // This variable should be set to false for devices, unlike the Raspberry Pi, that have GPU support
        public const bool DisableLiveCameraFeed = true;

        // Oxford Face API Primary should be entered here
        // You can obtain a subscription key for Face API by following the instructions here: https://www.projectoxford.ai/doc/general/subscription-key-mgmt
        public const string OxfordAPIKey = "Your Oxford subscription";
        
        // Name of the folder in which all Whitelist data is stored
        public const string WhiteListFolderName = "Coffee Management System Users";

        // Weight for coffee cup pressure pad
        public const int pressurepad = 400;

        // To disable connection with arduino
        public  const bool Enableconnection = false;

    }

    /// <summary>
    /// Constant variables that hold messages to be read via the SpeechHelper class
    /// </summary>
    public static class SpeechContants
    {
        public const string InitialGreetingMessage = "Welcome to the Coffee MAnagement System! Speech has been initialized.";

        public const string UserNotRecognizedMessage = "Sorry! I don't recognize you, so I cannot make your cofee.";
        public const string NoCameraMessage = "Sorry! It seems like your camera has not been fully initialized.";

        public static string GeneralGreetigMessage(string userName)
        {
            return "Welcome to the Coffee Management System " + userName + "! Your coffee will be ready soon.";
        }
    }

    /// <summary>
    /// Constant variables that hold values used to interact with device Gpio
    /// </summary>
    public static class GpioConstants
    {
        // The GPIO pin that the quickcoffee button is attached to
        public const int ButtonPinID = 7;

        // The GPIO pin that the relay is attached to
        public const int RelayLockPinID = 12;

       
    }
}
